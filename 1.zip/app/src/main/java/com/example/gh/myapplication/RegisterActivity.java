package com.example.gh.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;
import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;

public class RegisterActivity extends Activity{
    private static final int REQUEST_LOGIN= 0;
    @BindView(R.id.register) Button register;
    @BindView(R.id.text_name) EditText _username;
    @BindView(R.id.text_email) EditText _email;
    @BindView(R.id.text_age) EditText _age;
    @BindView(R.id.text_password) EditText _password;
    @BindView(R.id.text_password2) EditText _password2;
    @BindView(R.id.goto_login) TextView _gotologin;
    String usern;
    String pa;
    String pa2;
    String ema;



    @Override
    public void onCreate(Bundle bundle){
        super.onCreate(bundle);
        setContentView(R.layout.register);
        ButterKnife.bind(this);
        Bmob.initialize(this, "5c7ee47d296dada891717c7516bd18f7");


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent=new Intent();
//                intent.setClass(RegisterActivity.this,MainActivity.class);
//                startActivity(intent);
                toRegister();
            }
        });
        _gotologin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the Signup activity
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivityForResult(intent, REQUEST_LOGIN);
                finish();
                //overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);}
            }
        });

    }
    public void  toRegister(){
        BmobUser user =new BmobUser();
        usern=_username.getText().toString();
        pa=_password.getText().toString();
        pa2=_password2.getText().toString();
        ema=_email.getText().toString();

        Toast.makeText(getBaseContext(),usern,Toast.LENGTH_LONG).show();
        Toast.makeText(getBaseContext(),pa,Toast.LENGTH_LONG).show();
        user.setUsername(_username.getText().toString());
        user.setPassword(_password.getText().toString());
        user.setEmail(_email.getText().toString());
        // user.setMobilePhoneNumber(_mobileText.getText().toString());
        if(validate()){
            user.signUp(this, new SaveListener() {
                @Override
                public void onSuccess() {
                    Toast.makeText(getBaseContext(),"Register Success",Toast.LENGTH_LONG).show();
                    register.setEnabled(true);
                    setResult(RESULT_OK,null);
                    finish();
                    Intent intent =new Intent(RegisterActivity.this,LoginActivity.class);
                    startActivity(intent);
                }
                @Override
                public void onFailure(int i, String s) {

                    Toast.makeText(getBaseContext(),s,Toast.LENGTH_LONG).show();

                    register.setEnabled(true);
                }
            });
        }
        else{
            Toast.makeText(getBaseContext(),"Input Error",Toast.LENGTH_LONG).show();
        }
    }
    public boolean validate(){
        boolean val=true;
        String regex = "\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*";
        if(pa.length()==0||!(pa.equals(pa2))){
            val=false;
        }
        if(usern.length()==0){
            val=false;
        }
        if(ema.length()==0||!(ema.matches(regex))){
            val=false;
        }
        return val;
    }
}
