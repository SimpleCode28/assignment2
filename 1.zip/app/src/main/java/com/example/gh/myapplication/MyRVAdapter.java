package com.example.gh.myapplication;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.app.ListFragment;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

//public class CoachList extends Activity {
////
////    String[] players = {"Wang Mo", "Li Jian", "刘教练", "David Zhang", "赵武 教练", "Van Persie", "Oscar"};
////    String[] experience = {
////            "Perfection is not attainable, but if we chase perfection we can catch excellence",
////            "Health & Fitness Lifestyle Transformation.Gym doesn't change live, People do.",
////            "If we chase perfection we can catch excellence",
////            "Gym doesn't change live, People do.",
////            "An accomplished fitness trainer with seven years of experience n hand",
////            "Gym doesn't change live, People do.",
////            "Gym doesn't change live, People do."
////    };
////    int[] images = {R.drawable.trainer1, R.drawable.trainer2, R.drawable.trainer3, R.drawable.trainer4, R.drawable.trainer5, R.drawable.trainer6, R.drawable.athelet_1};
////
////    ArrayList<HashMap<String, String>> data = new ArrayList<HashMap<String, String>>();
////    SimpleAdapter adapter;
////
////    @Override
////    public void onCreate(Bundle savedInstanceState) {
////        // TODO Auto-generated method stub
////        super.onCreate(savedInstanceState);
////        setContentView(R.layout.courselist);
////        //MAP
////        HashMap<String, String> map = new HashMap<String, String>();
////
////        //FILL
////        for (int i = 0; i < players.length; i++) {
////            map = new HashMap<String, String>();
////            map.put("Player", players[i]);
////            map.put("Info",experience[i]);
////            map.put("Image", Integer.toString(images[i]));
////
////            data.add(map);
////        }
////
////        //KEYS IN MAP
////        String[] from = {"Player","Info", "Image"};
////
////        //IDS OF VIEWS
////        int[] to = {R.id.nameTxt, R.id.infoTxt, R.id.imageView1};
////
////        ListView trainer_list =findViewById(R.id.trainer_list);
////        //ADAPTER
////        adapter = new SimpleAdapter(getBaseContext(), data, R.layout.courselistitem, from, to);
////        trainer_list.setAdapter(adapter);
////
////    }
////
//////    @Override
//////    public void onStart() {
//////        // TODO Auto-generated method stub
//////        super.onStart();
//////
//////        getListView().setOnItemClickListener(new OnItemClickListener() {
//////
//////            @Override
//////            public void onItemClick(AdapterView<?> av, View v, int pos,
//////                                    long id) {
//////                // TODO Auto-generated method stub
//////
//////                Toast.makeText(getActivity(), data.get(pos).get("Player"), Toast.LENGTH_SHORT).show();
//////
//////            }
//////        });
//////    }
////
////}

public class MyRVAdapter  extends RecyclerView.Adapter<MyRVAdapter.PersonViewHolder> {

    List<Person> persons;
    public LayoutInflater inflater;

    MyRVAdapter(List<Person> persons){
        this.persons = persons;
    }

    public static class PersonViewHolder extends RecyclerView.ViewHolder {
        CardView cv;
        TextView personName;
        TextView personAge;
        ImageView personPhoto;

        PersonViewHolder(View itemView) {
            super(itemView);
            cv = (CardView)itemView.findViewById(R.id.cv);
            personName = (TextView)itemView.findViewById(R.id.person_name);
            personAge = (TextView)itemView.findViewById(R.id.person_age);
            personPhoto = (ImageView)itemView.findViewById(R.id.person_photo);
        }
    }

    @Override
    public int getItemCount() {
        return persons.size();
    }

    @NonNull
    @Override
    public PersonViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = inflater.from(viewGroup.getContext()).inflate(R.layout.courselistitem, null);
        return new PersonViewHolder(view);
    }

    @Override
    public void onBindViewHolder(PersonViewHolder personViewHolder, int i) {
        personViewHolder.personName.setText(persons.get(i).name);
        personViewHolder.personAge.setText(persons.get(i).age);
        personViewHolder.personPhoto.setImageResource(persons.get(i).photoId);
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

}

