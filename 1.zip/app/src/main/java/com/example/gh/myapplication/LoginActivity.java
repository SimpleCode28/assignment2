package com.example.gh.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;
import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.listener.SaveListener;

public class LoginActivity extends Activity{
    private static final int REQUEST_REGISTER= 0;

    @BindView(R.id.login) Button login;
    @BindView(R.id.goto_register) TextView _togoregister;
    @BindView(R.id.email) EditText _email;
    @BindView(R.id.password) EditText _password;
    String email;
    String password;
    //    final Button login=findViewById(R.id.login);
//    final TextView _forregister=findViewById(R.id.link_register);
//    final EditText _email=findViewById(R.id.email);
//    final EditText _password=findViewById(R.id.password);
    @Override
    public void onCreate(Bundle bundle){
        super.onCreate(bundle);
        setContentView(R.layout.login);
        Bmob.initialize(this, "5c7ee47d296dada891717c7516bd18f7");
        ButterKnife.bind(this);


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toLogin();
            }
        });
        _togoregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);
                startActivityForResult(intent, REQUEST_REGISTER);
                finish();
            }
        });
    }
    public void toLogin() {
        Log.d("LoginActivity", "Login");
        login.setEnabled(false);
        email = _email.getText().toString();
        password = _password.getText().toString();
        // TODO: Implement your own authentication logic here.
        BmobUser bu2 = new BmobUser();
        bu2.setUsername(email);
        bu2.setPassword(password);
        if(validate()){
            bu2.login(LoginActivity.this, new SaveListener() {
                @Override
                public void onSuccess() {
                    Toast.makeText(LoginActivity.this, "Login Success", Toast.LENGTH_SHORT).show();
                    login.setEnabled(true);
                    finish();
                    Intent intent = new Intent(LoginActivity.this,MainActivity.class);
                    startActivity(intent);
                    //通过BmobUser user = BmobUser.getCurrentUser(context)获取登录成功后的本地用户信息
                    //如果是自定义用户对象MyUser，可通过MyUser user = BmobUser.getCurrentUser(context,MyUser.class)获取自定义用户信息
                }
                @Override
                public void onFailure(int code, String msg) {
                    Toast.makeText(LoginActivity.this, "Login Failed"+msg, Toast.LENGTH_SHORT).show();
                    login.setEnabled(true);
                }
            });
        }
    }
    public boolean validate(){
        boolean val=true;
        String regex = "\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*";
        if(password.length()==0){
            val=false;
        }
        if(email.length()==0||!(email.matches(regex))){
            val=false;
        }
        return val;
    }



}
