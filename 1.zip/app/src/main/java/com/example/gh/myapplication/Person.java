package com.example.gh.myapplication;

import java.util.ArrayList;
import java.util.List;

public class Person {
    String name;
    String age;
    int photoId;

    Person(String name, String age, int photoId) {
        this.name = name;
        this.age = age;
        this.photoId = photoId;
    }
}
