package com.example.gh.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

import java.util.ArrayList;

public class List extends Activity {
    private ArrayList<Person> persons ;

    MyRVAdapter adapter;


    public void onCreate(Bundle savedInstanceState) {
       // TODO Auto-generated method stub
        initializeData();
        adapter = new MyRVAdapter(persons);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.courselist);
        RecyclerView rv = (RecyclerView)findViewById(R.id.rv);
        rv.setHasFixedSize(true);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(adapter);
    }


    public void onStart() {
//////        // TODO Auto-generated method stub
        super.onStart();

//       get().setOnItemClickListener(new AdapterView.OnItemClickListener() {
//
//           @Override
//          public void onItemClick(AdapterView<?> av, View v, int pos,
//                                  long id) {
//              // TODO Auto-generated method stub
//
//               Toast.makeText(getActivity(), data.get(pos).get("Player"), Toast.LENGTH_SHORT).show();
//
//           }
//        });
   }



    // This method creates an ArrayList that has three Person objects
// Checkout the project associated with this tutorial on Github if
// you want to use the same images.
    private void initializeData(){
        persons = new ArrayList<>();
        persons.add(new Person("Emma Wilson", "23 years old", R.drawable.trainer1));
        persons.add(new Person("Lavery Maiss", "25 years old", R.drawable.trainer2));
        persons.add(new Person("Lillie Watts", "35 years old", R.drawable.trainer3));
        persons.add(new Person("Emma Wilson", "23 years old", R.drawable.trainer4));
        persons.add(new Person("Lavery Maiss", "25 years old", R.drawable.trainer5));
        persons.add(new Person("Lillie Watts", "35 years old", R.drawable.trainer6));
    }


}

